package data.scripts;

//Requried for Example 1:
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.util.Misc;

//Additionally required for Example 2:
import com.fs.starfarer.api.campaign.PlanetSpecAPI;
import data.campaign.quests.lobsterBarEventCreator;
import data.campaign.quests.lobsterQuestCoordinator;

// lazy lib
// import org.lazywizard.lazylib.campaign.MessageUtils;

/**
 * This mod demonstrates the bare-minimum necessary code/scripting required to add a planet to an existing star system.
 * It is intended for those with minimal programming experience, let alone Java experience.
 * It tries to get the reader started with the bare basics that they can use to make simple, though impactful,
 * changes to their StarSector game.
 *
 * At times, some programming jargon will be defined and then used. Even if it doesn't make sense, the reader should
 * still be able to duplicate the code herein and modify it to obtain their own desired results.
 *
 * TModPlugin.java is a "class" file. It will be compiled by the game (ie Java) into byte-code (an actual .class file).
 */
public class BoggledTerraformingPlugin extends BaseModPlugin {

    @Override
    public void onNewGame()
    {
        //Player has ability on new game start.
    }

    public void afterGameSave()
    {
        Global.getSector().getCharacterData().addAbility("boggled_activate_euteck");
        Global.getSector().getCharacterData().addAbility("boggled_seed_lobsters");
    }

    public void beforeGameSave()
    {
        Global.getSector().getCharacterData().removeAbility("boggled_activate_euteck");
        Global.getSector().getCharacterData().removeAbility("boggled_seed_lobsters");
    }

    public void onGameLoad(boolean newGame)
    {
        BarEventManager barEventManager = BarEventManager.getInstance();

        // If the prerequisites for the quest have been met (optional) and the game isn't already aware of the bar event,
        // add it to the BarEventManager so that it shows up in bars
        if (lobsterQuestCoordinator.shouldOfferQuest() && !barEventManager.hasEventCreator(lobsterBarEventCreator.class))
        {
            barEventManager.addEventCreator(new lobsterBarEventCreator());
        }

        if (!Global.getSector().getPlayerFleet().hasAbility("boggled_activate_euteck"))
        {
            Global.getSector().getCharacterData().addAbility("boggled_activate_euteck");
        }

        if (!Global.getSector().getPlayerFleet().hasAbility("boggled_seed_lobsters"))
        {
            Global.getSector().getCharacterData().addAbility("boggled_seed_lobsters");
        }
    }
}