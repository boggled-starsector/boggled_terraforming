package data.campaign.quests;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarEvent;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventCreator;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventWithPerson;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.campaign.*;
import com.fs.starfarer.combat.entities.terrain.Planet;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin;
import com.fs.starfarer.loading.specs.PlanetSpec;
import com.fs.starfarer.rpg.Person;
import data.campaign.econ.items.euteckItemPlugin;

import java.util.*;

public class addMillerUreyDeviceToMarket extends BaseCommandPlugin
{
    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap)
    {
        if (dialog == null) return false;

        SectorEntityToken entity = dialog.getInteractionTarget();

        if(Global.getSettings().getBoolean("boggledMillerUreyDeviceCanBePurchasedFromBlackMarket") && entity != null && entity.getMarket() != null && !entity.getMarket().getFactionId().equals("neutral"))
        {
            MarketAPI market = entity.getMarket();
            if(market.hasCondition("ruins_scattered") || market.hasCondition("ruins_widespread") || market.hasCondition("ruins_extensive") || market.hasCondition("ruins_vast"))
            {
                Iterator allSubmarkets = market.getSubmarketsCopy().iterator();
                while(allSubmarkets.hasNext())
                {
                    SubmarketAPI submarket = (SubmarketAPI)allSubmarkets.next();
                    if(submarket.getName().contains("Black"))
                    {
                        CargoAPI blackMarketCargo = submarket.getCargo();

                        //Exit function if there's a MUD in stock
                        Iterator allCargoStacks = blackMarketCargo.getStacksCopy().iterator();
                        while(allCargoStacks.hasNext())
                        {
                            CargoStackAPI stack = (CargoStackAPI)allCargoStacks.next();
                            if(stack.getDisplayName().equals("Miller-Urey Device"))
                            {
                                return true;
                            }
                        }

                        blackMarketCargo.addSpecial(new SpecialItemData("euteck", null), 1.0F);
                    }
                }
            }

        }

        return true;
    }
}