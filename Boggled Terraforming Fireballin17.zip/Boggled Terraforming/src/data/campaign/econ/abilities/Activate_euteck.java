package data.campaign.econ.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberViewAPI;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import data.campaign.econ.boggledTerraformingTools;

public class Activate_euteck extends BaseDurationAbility
{
    public Activate_euteck() { }

    @Override
    protected void activateImpl()
    {
        CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        CargoAPI playerCargo = Global.getSector().getPlayerFleet().getCargo();
        CargoStackAPI euteckStack = null;

        Iterator allCargoStacks = playerCargo.getStacksCopy().iterator();
        while(allCargoStacks.hasNext())
        {
            CargoStackAPI stack = (CargoStackAPI)allCargoStacks.next();
            if(stack.getDisplayName().equals("Miller-Urey Device"))
            {
                euteckStack = stack;
                break;
            }
        }

        playerCargo.removeItems(CargoAPI.CargoItemType.SPECIAL, euteckStack.getData(), 1f);

        MarketAPI market = boggledTerraformingTools.getClosestPlanetToken(playerFleet).getMarket();
        market.addCondition("euteck_active");
        if(!market.hasTag("boggled_euteck_terraformed"))
        {
            market.addTag("boggled_euteck_terraformed");
        }

        boggledTerraformingTools.surveyAll(market);

        MessageIntel intel = new MessageIntel("Terraforming via Miller-Urey device of " + market.getName(), Misc.getBasePlayerColor());
        intel.addLine("    - Started");
        intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
        intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
        Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
    }

    @Override
    public boolean isUsable()
    {
        CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        CargoAPI playerCargo = playerFleet.getCargo();
        CargoStackAPI euteckStack = null;

        if (playerFleet.isInHyperspace() || Global.getSector().getPlayerFleet().isInHyperspaceTransition())
        {
            return false;
        }

        Iterator allCargoStacks = playerCargo.getStacksCopy().iterator();
        while(allCargoStacks.hasNext())
        {
            CargoStackAPI stack = (CargoStackAPI)allCargoStacks.next();
            if(stack.getDisplayName().equals("Miller-Urey Device"))
            {
                euteckStack = stack;
                break;
            }
        }

        if(euteckStack == null)
        {
            return false;
        }

        if(!(playerFleet.isInHyperspace() || Global.getSector().getPlayerFleet().isInHyperspaceTransition()) && !boggledTerraformingTools.planetInSystem(playerFleet))
        {
            return false;
        }

        SectorEntityToken closestPlanetToken = boggledTerraformingTools.getClosestPlanetToken(playerFleet);
        PlanetAPI closestPlanetAPI = ((PlanetAPI)closestPlanetToken);

        if(boggledTerraformingTools.getPlanetType(closestPlanetAPI).equals("unknown"))
        {
            return false;
        }
        else if(closestPlanetToken.getMarket() == null || !closestPlanetToken.getMarket().getFactionId().equals("player"))
        {
            return false;
        }
        else if(boggledTerraformingTools.getPlanetType(closestPlanetAPI).equals("gas_giant"))
        {
            return false;
        }
        else if(closestPlanetToken.getMarket().hasCondition("euteck_active"))
        {
            return false;
        }
        else if(closestPlanetAPI.getMarket().hasCondition("dark"))
        {
            return false;
        }
        else if(!boggledTerraformingTools.hasEuteckImprovableConditions(closestPlanetAPI))
        {
            return false;
        }
        else if(boggledTerraformingTools.getDistanceBetweenTokens(playerFleet, closestPlanetToken) > closestPlanetToken.getRadius() + 400f)
        {
            return false;
        }

        return !this.isOnCooldown() && this.disableFrames <= 0;
    }

    @Override
    public boolean hasTooltip() { return true; }

    @Override
    public void createTooltip(TooltipMakerAPI tooltip, boolean expanded)
    {
        Color highlight = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        LabelAPI title = tooltip.addTitle("Activate Miller-Urey Device");
        float pad = 10.0F;
        tooltip.addPara("Consume a Miller-Urey device from your inventory to terraform a world you control.", pad, highlight, new String[]{""});

        CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        CargoAPI playerCargo = playerFleet.getCargo();
        CargoStackAPI euteckStack = null;
        boolean planetCheckOK = true;

        if (playerFleet.isInHyperspace() || Global.getSector().getPlayerFleet().isInHyperspaceTransition())
        {
            tooltip.addPara("You cannot active a Miller-Urey device in hyperspace.", bad, pad);
            planetCheckOK = false;
        }

        Iterator allCargoStacks = playerCargo.getStacksCopy().iterator();
        while(allCargoStacks.hasNext())
        {
            CargoStackAPI stack = (CargoStackAPI)allCargoStacks.next();
            if(stack.getDisplayName().equals("Miller-Urey Device"))
            {
                euteckStack = stack;
                break;
            }
        }

        if(euteckStack == null)
        {
            tooltip.addPara("You do not have a Miller-Urey device in your inventory.", bad, pad);
            return;
        }

        if(!(playerFleet.isInHyperspace() || Global.getSector().getPlayerFleet().isInHyperspaceTransition()) && !boggledTerraformingTools.planetInSystem(playerFleet))
        {
            tooltip.addPara("There are no planets in this system.", bad, pad);
            planetCheckOK = false;
        }

        if(planetCheckOK)
        {
            SectorEntityToken closestPlanetToken = boggledTerraformingTools.getClosestPlanetToken(playerFleet);
            PlanetAPI closestPlanetAPI = ((PlanetAPI)closestPlanetToken);

            if(this.isUsable())
            {
                tooltip.addPara("Miller-Urey device terraforming target: %s\n\nConditions that can be improved by a Miller-Urey device: Dust storms, suboptimal atmospheric density and/or toxicity, extreme weather, extreme temperatures, radiation, inimical biosphere, meteor impacts, pollution, suboptimal farmland, and less than common organics.\n\nConditions that cannot be improved by a Miller-Urey device: Moderately unsuitable temperatures, tectonic activity (can be changed via settings.csv), lack of a mild climate, high or low gravity (can be changed via settings.csv), lack of sufficient light, and lack of ore or volatiles.\n\nNote: It may be necessary to build stellar reflectors if temperatures are still outside the ideal range following completion of Miller-Urey Device terraforming.", pad, highlight, new String[]{closestPlanetToken.getName()});
            }

            if(boggledTerraformingTools.getPlanetType(closestPlanetAPI).equals("unknown"))
            {
                tooltip.addPara("The planet closest to your location is " + closestPlanetToken.getName() + ". ERROR: This planet type appears to be unsupported in Boggled's Terraforming Mod. Please let Boggled know about this in the forum thread for his terraforming mod so he can add support. Unsupported planet type: " + closestPlanetAPI.getTypeId(), bad, pad);
            }
            else if(boggledTerraformingTools.getPlanetType(closestPlanetAPI).equals("gas_giant"))
            {
                tooltip.addPara("The planet closest to your location is " + closestPlanetToken.getName() + ". Even a Miller-Urey device cannot terraform a gas giant.", bad, pad);
            }
            else if(closestPlanetToken.getMarket().hasCondition("euteck_active"))
            {
                tooltip.addPara("The planet closest to your location is " + closestPlanetToken.getName() + ". A Miller-Urey device is already active there.", bad, pad);
            }
            else if(closestPlanetAPI.getMarket().hasCondition("dark"))
            {
                tooltip.addPara("The planet closest to your location is " + closestPlanetToken.getName() + ". A Miller-Urey device would be ineffective there because an Earth-like biosphere cannot take hold on a world with no light.", bad, pad);
            }
            else if(!boggledTerraformingTools.hasEuteckImprovableConditions(closestPlanetAPI))
            {
                tooltip.addPara("The planet closest to your location is " + closestPlanetToken.getName() + ". Conditions on " + closestPlanetToken.getName() + " would not see any improvement from a Miller-Urey device.\n\nConditions that can be improved by a Miller-Urey device: Dust storms, suboptimal atmospheric density and/or toxicity, extreme weather, extreme temperatures, radiation, inimical biosphere, meteor impacts, pollution, suboptimal farmland, and less than common organics.\n\nConditions that cannot be improved by a Miller-Urey device: Commodity shortages, unrest, rogue AI cores, presence of ruins, decivilized subpopulations, moderately unsuitable temperatures, tectonic activity, lack of a mild climate, high or low gravity, lack of sufficient light, and lack of ore or volatiles.\n\nNote: It may be necessary to build stellar reflectors if temperatures are still outside the ideal range following completion of Miller-Urey device terraforming.", bad, pad);
            }
            else if(closestPlanetToken.getMarket() == null || !closestPlanetToken.getMarket().getFactionId().equals("player"))
            {
                tooltip.addPara("The planet closest to your location is " + closestPlanetToken.getName() + ". You can only activate a Miller-Urey device on planets you control.", bad, pad);
            }
            else if(boggledTerraformingTools.getDistanceBetweenTokens(playerFleet, closestPlanetToken) > closestPlanetToken.getRadius() + 400f)
            {
                float distanceInSu = boggledTerraformingTools.getDistanceBetweenTokens(playerFleet, closestPlanetToken) / 2000f;
                String distanceInSuString = String.format("%.1f", distanceInSu);
                float requiredDistanceInSu = (closestPlanetToken.getRadius() + 400f) / 2000f;
                String requiredDistanceInSuString = String.format("%.2f", requiredDistanceInSu);
                tooltip.addPara("The planet closest to your location is " + closestPlanetToken.getName() + ". Your fleet is " + distanceInSuString + " stellar units away. You must be within " + requiredDistanceInSuString + " stellar units to activate a Miller-Urey device.", bad, pad);
            }
        }
    }

    @Override
    public boolean isTooltipExpandable() { return false; }

    @Override
    protected void applyEffect(float v, float v1) { }

    @Override
    protected void deactivateImpl() { }

    @Override
    protected void cleanupImpl() { }
}