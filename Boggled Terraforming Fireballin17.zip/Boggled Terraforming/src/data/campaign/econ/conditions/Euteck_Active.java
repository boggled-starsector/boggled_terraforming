
package data.campaign.econ.conditions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.campaign.*;
import com.fs.starfarer.combat.entities.terrain.Planet;
import java.awt.*;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import com.fs.starfarer.loading.specs.PlanetSpec;
import data.campaign.econ.boggledTerraformingTools;

public class Euteck_Active extends BaseHazardCondition
{
    private int monthsElapsed = 0;
    private int lastMonthChecked = 0;

    public Euteck_Active() { }

    public void advance(float amount)
    {
        super.advance(amount);

        MarketAPI market = this.market;
        StarSystemAPI system = market.getStarSystem();

        //Reload variables from persistent market tags and remove the tags
        for(int i = 0; i <= (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithMUD") + 1); i++)
        {
            if(market.hasTag(i + "euteckMonthsElapsed"))
            {
                monthsElapsed = i;
                market.removeTag(i + "euteckMonthsElapsed");
                break;
            }
        }

        for(int i = 0; i <= (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithMUD") + 1); i++)
        {
            if(market.hasTag(i + "euteckLastMonthChecked"))
            {
                lastMonthChecked = i;
                market.removeTag(i + "euteckLastMonthChecked");
                break;
            }
        }

        //Check if monthsElapsed should be incremented
        CampaignClockAPI clock = Global.getSector().getClock();
        if(clock.getMonth() != lastMonthChecked)
        {
            monthsElapsed++;
            lastMonthChecked = clock.getMonth();
        }

        if(monthsElapsed >= (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithMUD") + 1))
        {
            this.market.addTag("euteckTerraformTriggerTrue");
        }

        //Check if we should fire the terraforming code
        if(market.hasTag("euteckTerraformTriggerTrue") && !boggledTerraformingTools.playerTooClose(system))
        {
            market.removeTag("euteckTerraformTriggerTrue");
            terraformEuteck(market);
        }

        //Make sure we can't write a tag with months elapsed more than thirteen because the for loop above won't find it.
        if(monthsElapsed > (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithMUD") + 1))
        {
            monthsElapsed = (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithMUD") + 1);
        }

        //Replace persistent tags. I don't think the game can crash and/or be closed between the tag deletion and replacement.
        market.addTag(monthsElapsed + "euteckMonthsElapsed");
        market.addTag(lastMonthChecked + "euteckLastMonthChecked");
    }

    public void apply(String id) {
        super.apply(id);
    }

    public void unapply(String id) {
        super.unapply(id);
    }

    public Map<String, String> getTokenReplacements() {
        return super.getTokenReplacements();
    }

    public boolean showIcon() {
        return true;
    }

    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded)
    {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        int monthsLeft = (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithMUD") + 1) - monthsElapsed;
        if(monthsLeft > 1)
        {
            tooltip.addPara("Approximately %s months remaining until terraforming is completed at " + this.market.getName() + ".", opad, highlight, new String[]{"" + monthsLeft});
        }
        else if(monthsLeft == 1)
        {
            tooltip.addPara("Approximately %s month remaining until terraforming is completed at " + this.market.getName() + ".", opad, highlight, new String[]{"" + monthsLeft});
        }
        else if(monthsLeft <= 0)
        {
            tooltip.addPara("Terraforming at " + this.market.getName() + " is almost complete. If you travel far enough away from this system, terraforming will be finished before you return.", opad, highlight, new String[]{""});
        }
    }

    private void terraformEuteck(MarketAPI market)
    {
        String newPlanetType = "terran";
        PlanetSpecAPI myspec = market.getPlanetEntity().getSpec();
        Iterator var4 = Global.getSettings().getAllPlanetSpecs().iterator();
        while(var4.hasNext()) {
            PlanetSpecAPI spec = (PlanetSpecAPI)var4.next();
            if (spec.getPlanetType().equals(newPlanetType))
            {
                myspec.setAtmosphereColor(spec.getAtmosphereColor());
                myspec.setAtmosphereThickness(spec.getAtmosphereThickness());
                myspec.setAtmosphereThicknessMin(spec.getAtmosphereThicknessMin());
                myspec.setCloudColor(spec.getCloudColor());
                myspec.setCloudRotation(spec.getCloudRotation());
                myspec.setCloudTexture(spec.getCloudTexture());
                myspec.setGlowColor(spec.getGlowColor());
                myspec.setGlowTexture(spec.getGlowTexture());
                myspec.setIconColor(spec.getIconColor());
                myspec.setPlanetColor(spec.getPlanetColor());
                myspec.setStarscapeIcon(spec.getStarscapeIcon());
                myspec.setTexture(spec.getTexture());
                myspec.setUseReverseLightForGlow(spec.isUseReverseLightForGlow());
                ((PlanetSpec)myspec).planetType = newPlanetType;
                ((PlanetSpec)myspec).name = spec.getName();
                ((PlanetSpec)myspec).descriptionId = ((PlanetSpec)spec).descriptionId;
                break;
            }
        }
        market.getPlanetEntity().applySpecChanges();

        if(market.hasCondition("low_gravity") && Global.getSettings().getBoolean("boggledMillerUreyDeviceFixesGravityConditions"))
        {
            market.removeCondition("low_gravity");
        }

        if(market.hasCondition("high_gravity") && Global.getSettings().getBoolean("boggledMillerUreyDeviceFixesGravityConditions"))
        {
            market.removeCondition("high_gravity");
        }

        if(market.hasCondition("tectonic_activity") && Global.getSettings().getBoolean("boggledMillerUreyDeviceFixesTectonicConditions"))
        {
            market.removeCondition("tectonic_activity");
        }

        if(market.hasCondition("extreme_tectonic_activity") && Global.getSettings().getBoolean("boggledMillerUreyDeviceFixesTectonicConditions"))
        {
            market.removeCondition("extreme_tectonic_activity");
        }

        if(market.hasCondition("water_surface"))
        {
            market.removeCondition("water_surface");
        }

        if(market.hasCondition("US_storm"))
        {
            market.removeCondition("US_storm");
        }

        if(!market.hasCondition("habitable"))
        {
            market.addCondition("habitable");
        }

        if(!market.hasCondition("mild_climate"))
        {
            market.addCondition("mild_climate");
        }

        if(market.hasCondition("very_cold"))
        {
            market.removeCondition("very_cold");
            market.addCondition("cold");
        }

        if(market.hasCondition("very_hot"))
        {
            market.removeCondition("very_hot");
            market.addCondition("hot");
        }

        if(market.hasCondition("no_atmosphere"))
        {
            market.removeCondition("no_atmosphere");
        }

        if(market.hasCondition("thin_atmosphere"))
        {
            market.removeCondition("thin_atmosphere");
        }

        if(market.hasCondition("toxic_atmosphere"))
        {
            market.removeCondition("toxic_atmosphere");
        }

        if(market.hasCondition("dense_atmosphere"))
        {
            market.removeCondition("dense_atmosphere");
        }

        if(market.hasCondition("extreme_weather"))
        {
            market.removeCondition("extreme_weather");
        }

        if(market.hasCondition("irradiated"))
        {
            market.removeCondition("irradiated");
        }

        if(market.hasCondition("inimical_biosphere"))
        {
            market.removeCondition("inimical_biosphere");
        }

        if(market.hasCondition("meteor_impacts"))
        {
            market.removeCondition("meteor_impacts");
        }

        if(market.hasCondition("pollution"))
        {
            market.removeCondition("pollution");
        }

        if(market.hasCondition("organics_trace"))
        {
            market.removeCondition("organics_trace");
        }

        if(!market.hasCondition("organics_common") && !market.hasCondition("organics_abundant") && !market.hasCondition("organics_plentiful"))
        {
            market.addCondition("organics_common");
        }

        if(market.hasCondition("farmland_poor"))
        {
            market.removeCondition("farmland_poor");
        }
        else if(market.hasCondition("farmland_adequate"))
        {
            market.removeCondition("farmland_adequate");
        }
        else if(market.hasCondition("farmland_rich"))
        {
            market.removeCondition("farmland_rich");
        }

        if(!market.hasCondition("farmland_bountiful"))
        {
            market.addCondition("farmland_bountiful");
        }

        boggledTerraformingTools.surveyAll(market);
        boggledTerraformingTools.refreshAquacultureAndFarming(market);
        boggledTerraformingTools.refreshSupplyAndDemand(market);

        if (market.isPlayerOwned())
        {
            MessageIntel intel = new MessageIntel("Terraforming via Miller-Urey device of " + market.getName(), Misc.getBasePlayerColor());
            intel.addLine("    - Completed");
            intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
            intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
            Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
        }

        market.removeTag("euteckTerraformTriggerTrue");

        for(int i = 0; i <= 13; i++)
        {
            if(market.hasTag(i + "euteckMonthsElapsed"))
            {
                market.removeTag(i + "euteckMonthsElapsed");
            }
        }

        for(int i = 0; i <= 13; i++)
        {
            if(market.hasTag(i + "euteckLastMonthChecked"))
            {
                market.removeTag(i + "euteckLastMonthChecked");
            }
        }

        market.removeCondition("euteck_active");
    }
}
