
package data.campaign.econ.conditions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignClockAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.util.Misc;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import data.campaign.econ.boggledTerraformingTools;

public class Stellar_Shade extends BaseHazardCondition {

    public Stellar_Shade() { }

    private int lastDayChecked = 0;

    public void advance(float amount)
    {
        MarketAPI market = this.market;

        CampaignClockAPI clock = Global.getSector().getClock();
        if(clock.getDay() != lastDayChecked)
        {
            boggledTerraformingTools.surveyAll(market);
            boggledTerraformingTools.refreshAquacultureAndFarming(market);
            boggledTerraformingTools.refreshSupplyAndDemand(market);
            lastDayChecked = clock.getDay();
        }

        //"Uninstalls" the stellar mirrors if the player removes the industry
        if(market.hasCondition("stellar_shade") && boggledTerraformingTools.numShadesInOrbit(market) == 3 && !market.hasIndustry("STELLAR_SHADE_ARRAY"))
        {
            boggledTerraformingTools.clearReflectorsInOrbit(market);

            if(market.hasTag("boggled_hot_removed"))
            {
                market.removeTag("boggled_hot_removed");
                market.addCondition("hot");
            }

            if(market.hasTag("boggled_very_hot_removed"))
            {
                market.removeTag("boggled_very_hot_removed");
                market.addCondition("very_hot");
            }

            if(!market.hasTag("boggled_euteck_terraformed"))
            {
                market.addCondition("deterraforming_tracker");
            }

            boggledTerraformingTools.surveyAll(market);
            boggledTerraformingTools.refreshSupplyAndDemand(market);
            boggledTerraformingTools.refreshAquacultureAndFarming(market);

            if (this.market.isPlayerOwned() && this.market.hasTag("boggled_terraformed") && !this.market.hasTag("boggled_euteck_terraformed"))
            {
                MessageIntel intel = new MessageIntel("Terraforming of " + market.getName(), Misc.getBasePlayerColor());
                intel.addLine("    - Regressing to less ideal planet type (ETA two cycles)");
                intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
            }

            if(this.market.hasCondition("stellar_shade"))
            {
                this.market.removeCondition("stellar_shade");
            }
        }
    }

    public void apply(String id) {
        super.apply(id);
    }

    public void unapply(String id) {
        super.unapply(id);
    }

    public Map<String, String> getTokenReplacements() {
        return super.getTokenReplacements();
    }
}
