
package data.campaign.econ.conditions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.campaign.CircularFleetOrbit;
import com.fs.starfarer.campaign.CircularOrbit;
import com.fs.starfarer.campaign.CircularOrbitPointDown;
import com.fs.starfarer.campaign.CircularOrbitWithSpin;
import com.fs.starfarer.combat.entities.terrain.Planet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import data.campaign.econ.boggledTerraformingTools;

public class Deterraforming_Tracker extends BaseHazardCondition
{
    private int lastMonthChecked = 0;
    private int monthsElapsed = 0;

    public Deterraforming_Tracker() { }

    public void advance(float amount)
    {
        super.advance(amount);

        MarketAPI market = this.market;
        StarSystemAPI system = market.getStarSystem();

        //Reload variables from persistent market tags and remove the tags
        for(int i = 0; i <= 25; i++)
        {
            if(market.hasTag(i + "deterraformMonthsElapsed"))
            {
                monthsElapsed = i;
                market.removeTag(i + "deterraformMonthsElapsed");
                break;
            }
        }

        for(int i = 0; i <= 25; i++)
        {
            if(market.hasTag(i + "deterraformLastMonthChecked"))
            {
                lastMonthChecked = i;
                market.removeTag(i + "deterraformLastMonthChecked");
                break;
            }
        }

        //Check if monthsElapsed should be incremented
        CampaignClockAPI clock = Global.getSector().getClock();
        if(clock.getMonth() != lastMonthChecked)
        {
            monthsElapsed++;
            lastMonthChecked = clock.getMonth();
        }

        if(market.hasTag("boggled_euteck_terraformed") || !market.hasTag("boggled_terraformed") || (market.hasIndustry("STELLAR_MIRROR_ARRAY") && market.getIndustry("STELLAR_MIRROR_ARRAY").isFunctional()) || (market.hasIndustry("STELLAR_SHADE_ARRAY") && market.getIndustry("STELLAR_SHADE_ARRAY").isFunctional()))
        {
            market.removeCondition("deterraforming_tracker");
        }

        if(market.hasTag("boggled_terraformed") && monthsElapsed >= 24)
        {
           market.addTag("deterraformTriggerTrue");
        }

        if(market.hasTag("deterraformTriggerTrue") && !boggledTerraformingTools.playerTooClose(system))
        {
            market.removeTag("deterraformTriggerTrue");
            boggledTerraformingTools.deterraform(market);
        }

        //Make sure we can't write a tag with months elapsed more than 25 because the for loop above won't find it.
        if(monthsElapsed > 25)
        {
            monthsElapsed = 25;
        }

        //Replace persistent tags. I don't think the game can crash and/or be closed between the tag deletion and replacement.
        market.addTag(monthsElapsed + "deterraformMonthsElapsed");
        market.addTag(lastMonthChecked + "deterraformLastMonthChecked");
    }

    public void apply(String id) { super.apply(id); }

    public void unapply(String id) { super.unapply(id); }

    public Map<String, String> getTokenReplacements() { return super.getTokenReplacements(); }

    public boolean showIcon() { return false; }
}
