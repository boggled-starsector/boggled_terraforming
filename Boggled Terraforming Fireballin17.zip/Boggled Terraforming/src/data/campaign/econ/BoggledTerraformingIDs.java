package data.campaign.econ;

public class BoggledTerraformingIDs
{
    public static class BoggledTerraformingIndustryIDs
    {
        public static final String ISMARA_SLING = "ISMARA_SLING";
        public static final String STELLAR_MIRROR_ARRAY = "STELLAR_MIRROR_ARRAY";
        public static final String STELLAR_SHADE_ARRAY = "STELLAR_SHADE_ARRAY";
        public static final String MILITARY_POLICE_HEADQUARTERS = "MILITARY_POLICE_HEADQUARTERS";
        public static final String ATMOSPHERE_ADJUSTER = "ATMOSPHERE_ADJUSTER";
    }
}