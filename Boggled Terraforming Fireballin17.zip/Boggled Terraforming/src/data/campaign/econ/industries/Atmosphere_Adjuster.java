package data.campaign.econ.industries;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.*;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.econ.impl.Farming;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.IconRenderMode;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.CoreCampaignPluginImpl;
import com.fs.starfarer.api.impl.campaign.CoreScript;
import com.fs.starfarer.api.impl.campaign.events.CoreEventProbabilityManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposableLuddicPathFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposablePirateFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetRouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.MercFleetManagerV2;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.campaign.*;
import com.fs.starfarer.campaign.econ.Market;
import com.fs.starfarer.loading.specs.PlanetSpec;
import data.campaign.econ.BoggledTerraformingIDs;
import data.campaign.econ.boggledTerraformingTools;
import data.campaign.econ.plugins.BoggledNanoforgeInstallableItemPlugin;
import java.text.DecimalFormat;

public class Atmosphere_Adjuster extends BaseIndustry
{
    private float progressRequirement = 3000;
    private float progressCounter = 0;
    private int lastDayChecked = 0;
    private boolean terraformVariantToTerranTrigger = false;

    protected SpecialItemData nanoforge = null;

    public void advance(float amount)
    {
        super.advance(amount);

        MarketAPI market = this.market;
        PlanetAPI planet = market.getPlanetEntity();
        StarSystemAPI system = market.getStarSystem();

        if (this.isFunctional())
        {
            CampaignClockAPI clock = Global.getSector().getClock();

            if(clock.getDay() != lastDayChecked)
            {
                lastDayChecked = clock.getDay();
                if(this.nanoforge != null && this.nanoforge.getId().equals("pristine_nanoforge"))
                {
                    progressCounter = progressCounter + 4;
                }
                else if(this.nanoforge != null && this.nanoforge.getId().equals("corrupted_nanoforge"))
                {
                    progressCounter = progressCounter + 2;
                }
                else
                {
                    progressCounter++;
                }
            }

            if(progressCounter >= progressRequirement)
            {
                if(boggledTerraformingTools.getPlanetType(planet).equals("toxic"))
                {
                    terraformVariantToTerranTrigger = true;
                }
                else if(market.hasCondition("toxic_atmosphere") || (market.hasCondition("pollution") && Global.getSettings().getBoolean("boggledAtmosphereAdjusterClearsPollution")))
                {
                    if(market.hasCondition("toxic_atmosphere"))
                    {
                        market.removeCondition("toxic_atmosphere");
                    }

                    if(market.hasCondition("pollution") && Global.getSettings().getBoolean("boggledAtmosphereAdjusterClearsPollution"))
                    {
                        market.removeCondition("pollution");
                    }

                    removeAtmosphereAdjuster();
                }
                else if(market.hasTag("boggled_euteck_terraformed"))
                {
                    removeAtmosphereAdjuster();
                }
                else
                {
                    removeAtmosphereAdjuster();
                }
            }

            if(!boggledTerraformingTools.playerTooClose(system) && terraformVariantToTerranTrigger)
            {
                boggledTerraformingTools.terraformVariantToTerran(market);

                removeAtmosphereAdjuster();
            }
        }
    }

    public void removeAtmosphereAdjuster()
    {
        if(this.market.hasIndustry("ATMOSPHERE_ADJUSTER"))
        {
            this.market.removeIndustry("ATMOSPHERE_ADJUSTER", null, false);
        }
    }

    public void addInstalledItemsSection(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded)
    {
        float opad = 10.0F;
        FactionAPI faction = this.market.getFaction();
        Color color = faction.getBaseUIColor();
        Color dark = faction.getDarkUIColor();
        LabelAPI heading = tooltip.addSectionHeading("Items", color, dark, Alignment.MID, opad);
        boolean addedSomething = false;
        if (this.aiCoreId != null)
        {
            AICoreDescriptionMode aiCoreDescMode = AICoreDescriptionMode.INDUSTRY_TOOLTIP;
            this.addAICoreSection(tooltip, this.aiCoreId, aiCoreDescMode);
            addedSomething = true;
        }

        addedSomething |= this.addNonAICoreInstalledItems(mode, tooltip, expanded);
        if (!addedSomething)
        {
            heading.setText("No items installed");
        }
    }

    protected boolean addNonAICoreInstalledItems(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded)
    {
        if (this.nanoforge == null)
        {
            return false;
        }
        else
        {
            float opad = 10.0F;
            FactionAPI faction = this.market.getFaction();
            Color color = faction.getBaseUIColor();
            Color dark = faction.getDarkUIColor();
            SpecialItemSpecAPI nanoforgeSpec = Global.getSettings().getSpecialItemSpec(this.nanoforge.getId());
            TooltipMakerAPI text = tooltip.beginImageWithText(nanoforgeSpec.getIconName(), 48.0F);
            BoggledNanoforgeInstallableItemPlugin.NanoforgeEffect effect = (BoggledNanoforgeInstallableItemPlugin.NanoforgeEffect)BoggledNanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.get(this.nanoforge.getId());
            effect.addItemDescription(text, this.nanoforge, InstallableIndustryItemPlugin.InstallableItemDescriptionMode.INDUSTRY_TOOLTIP);
            tooltip.addImageWithText(opad);
            return true;
        }
    }

    public List<InstallableIndustryItemPlugin> getInstallableItems()
    {
        ArrayList<InstallableIndustryItemPlugin> list = new ArrayList();
        list.add(new BoggledNanoforgeInstallableItemPlugin(this));
        return list;
    }

    public void initWithParams(List<String> params)
    {
        super.initWithParams(params);
        Iterator var3 = params.iterator();

        while(var3.hasNext()) {
            String str = (String)var3.next();
            if (BoggledNanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.containsKey(str))
            {
                this.setNanoforge(new SpecialItemData(str, (String)null));
                break;
            }
        }

    }

    public List<SpecialItemData> getVisibleInstalledItems()
    {
        List<SpecialItemData> result = super.getVisibleInstalledItems();
        if (this.nanoforge != null)
        {
            result.add(this.nanoforge);
        }

        return result;
    }

    public void setNanoforge(SpecialItemData nanoforge)
    {
        this.nanoforge = nanoforge;
    }

    public SpecialItemData getNanoforge() {
        return this.nanoforge;
    }

    public SpecialItemData getSpecialItem() {
        return this.nanoforge;
    }

    public void setSpecialItem(SpecialItemData special) {
        this.nanoforge = special;
    }

    public boolean wantsToUseSpecialItem(SpecialItemData data)
    {
        if (this.nanoforge != null && "corrupted_nanoforge".equals(this.nanoforge.getId()) && data != null && "pristine_nanoforge".equals(data.getId()))
        {
            return true;
        }
        else
        {
            return this.nanoforge == null && data != null && BoggledNanoforgeInstallableItemPlugin.NANOFORGE_EFFECTS.containsKey(data.getId());
        }
    }

    public boolean canBeDisrupted() {
        return false;
    }

    public float getBaseUpkeep()
    {
        //This fixes the erroneous upkeep calculation on the industry install page
        return this.getSpec().getUpkeep();
    }

    public void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Massively reduces upkeep cost.", 0.0F, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Massively reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void addBetaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Beta-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Beta-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Greatly reduces upkeep cost.", opad, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Greatly reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void addGammaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Gamma-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Gamma-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Reduces upkeep cost.", opad, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void applyAICoreToIncomeAndUpkeep() {
        //This code is overwritten below because all three AI cores reduce the upkeep by a different amount
    }

    public void updateAICoreToSupplyAndDemandModifiers() {
        //There is no supply or demand for this industry, but put this here as a placeholder for if that changes
    }

    public void applyIncomeAndUpkeep(float sizeOverride) {
        float size = (float)this.market.getSize();
        if (sizeOverride >= 0.0F) {
            size = sizeOverride;
        }

        float alphaCoreMult = 0.25f;
        float betaCoreMult = 0.50f;
        float gammaCoreMult = 0.75f;

        float sizeMult = getSizeMult(size);
        sizeMult = 1.0f; //Prevents colony size from altering the upkeep amount
        float stabilityMult = this.market.getIncomeMult().getModifiedValue();
        float upkeepMult = this.market.getUpkeepMult().getModifiedValue();
        int income = (int)(this.getSpec().getIncome() * sizeMult);
        if (income != 0) {
            this.getIncome().modifyFlatAlways("ind_base", (float)income, "Base value");
            this.getIncome().modifyMultAlways("ind_stability", stabilityMult, "Market income multiplier");
        } else {
            this.getIncome().unmodifyFlat("ind_base");
            this.getIncome().unmodifyMult("ind_stability");
        }

        int upkeep = (int)(this.getSpec().getUpkeep() * sizeMult);
        if(!this.market.isPlayerOwned())
        {
            upkeep = 0;
        }
        if (upkeep != 0) {
            this.getUpkeep().modifyFlatAlways("ind_base", (float)upkeep, "Base value");
            this.getUpkeep().modifyMultAlways("ind_hazard", upkeepMult, "Market upkeep multiplier");
            if(this.aiCoreId == null)
            {
                //Do not reduce upkeep, and remove any previous upkeep-reducing effects from AI cores that were previously installed
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("alpha_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_alpha", alphaCoreMult, "Alpha Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("beta_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_beta", betaCoreMult, "Beta Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("gamma_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_gamma", gammaCoreMult, "Gamma Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
            }
        } else {
            this.getUpkeep().unmodifyFlat("ind_base");
            this.getUpkeep().unmodifyMult("ind_hazard");
        }

        this.applyAICoreToIncomeAndUpkeep();
        if (!this.isFunctional()) {
            this.getIncome().unmodifyFlat("ind_base");
            this.getIncome().unmodifyMult("ind_stability");
        }
    }

    @Override
    public void finishBuildingOrUpgrading() {
        super.finishBuildingOrUpgrading();
    }

    @Override
    protected void buildingFinished()
    {
        super.buildingFinished();

        this.market.addTag("BOGGLED_ATMOSPHERE_ADJUSTER_SHOW_TOOLTIP");
    }

    @Override
    public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade)
    {
        //mode is null if removed by the industry itself when terraforming is complete
        if(mode == null || mode.equals(MarketAPI.MarketInteractionMode.REMOTE))
        {
            if (this.nanoforge != null)
            {
                CargoAPI cargo = this.market.getSubmarket("storage").getCargo();
                if (cargo != null)
                {
                    cargo.addSpecial(this.nanoforge, 1.0F);
                }
            }

            if (this.aiCoreId != null)
            {
                CargoAPI cargo = this.market.getSubmarket("storage").getCargo();
                if (cargo != null)
                {
                    cargo.addCommodity(this.aiCoreId, 1.0F);
                }
            }
        }
        else if(mode.equals(MarketAPI.MarketInteractionMode.LOCAL))
        {
            if (this.nanoforge != null)
            {
                CargoAPI cargo = Global.getSector().getPlayerFleet().getCargo();
                if (cargo != null)
                {
                    cargo.addSpecial(this.nanoforge, 1.0F);
                }
            }

            if (this.aiCoreId != null)
            {
                CargoAPI cargo = Global.getSector().getPlayerFleet().getCargo();
                if (cargo != null)
                {
                    cargo.addCommodity(this.aiCoreId, 1.0F);
                }
            }
        }

        this.market.removeTag("BOGGLED_ATMOSPHERE_ADJUSTER_SHOW_TOOLTIP");
    }

    @Override
    public void apply() {
        super.apply(true);

        this.applyIncomeAndUpkeep(-1f);
    }

    @Override
    public void unapply() {
        super.unapply();
    }

    @Override
    public void startBuilding() {
        super.startBuilding();
    }

    @Override
    public boolean isAvailableToBuild()
    {
        MarketAPI market = this.market;

        //Check to ensure non-player factions cannot build this
        if(!market.isPlayerOwned())
        {
            return false;
        }

        //Can't be built by station markets
        if(market.getPrimaryEntity().hasTag("station")) { return false; }

        PlanetAPI planet = market.getPlanetEntity();

        //Toxic planets and toxic atmosphere condition
        if(boggledTerraformingTools.getPlanetType(planet).equals("toxic") || market.hasCondition("toxic_atmosphere") || (market.hasCondition("pollution") && Global.getSettings().getBoolean("boggledAtmosphereAdjusterClearsPollution")))
        {
            return true;
        }

        return false;
    }

    @Override
    public boolean showWhenUnavailable()
    {
        return true;
    }

    @Override
    public String getUnavailableReason()
    {
        MarketAPI market = this.market;

        //Can't be built by station markets
        if(market.getPrimaryEntity().hasTag("station")) { return "Stations cannot be terraformed."; }

        PlanetAPI planet = market.getPlanetEntity();

        //Toxic planets and toxic atmosphere condition only
        if(!boggledTerraformingTools.getPlanetType(planet).equals("toxic") && !market.hasCondition("toxic_atmosphere") && !(market.hasCondition("pollution") && Global.getSettings().getBoolean("boggledAtmosphereAdjusterClearsPollution")))
        {
            if(Global.getSettings().getBoolean("boggledAtmosphereAdjusterClearsPollution"))
            {
                return "The atmosphere adjuster is designed to alter atmospheric composition to remove toxic elements and pollution. It would be pointless to build one on " + market.getName() + " because the atmosphere is not toxic or polluted.";
            }
            else
            {
                return "The atmosphere adjuster is designed to alter atmospheric composition to remove toxic elements. It would be pointless to build one on " + market.getName() + " because the atmosphere is not toxic.";
            }
        }

        return "Error: There was a code logic problem in the atmosphere adjuster getUnavailableReason() function. Please tell Boggled about this in the forum thread for this mod so he can fix it.";
    }

    public float getPatherInterest() {
        if (this.aiCoreId == null) {
            return 10.0F;
        } else if ("alpha_core".equals(this.aiCoreId)) {
            return 14.0F;
        } else if ("beta_core".equals(this.aiCoreId)) {
            return 12.0F;
        } else {
            return 11f;
        }
    }

    @Override
    protected void addRightAfterDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode)
    {
        MarketAPI market = this.market;
        StarSystemAPI system = market.getStarSystem();

        if(this.isBuilding() || !market.hasTag("BOGGLED_ATMOSPHERE_ADJUSTER_SHOW_TOOLTIP"))
        {
            return;
        }

        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        //Inserts terraforming progress after description
        if(this.isFunctional())
        {
            DecimalFormat format = new DecimalFormat("##.0000");
            float percentComplete = (progressCounter / progressRequirement) * 100;

            if(progressCounter >= progressRequirement && boggledTerraformingTools.playerTooClose(system))
            {
                tooltip.addPara("Atmospheric detoxification on " + this.market.getName() + " is almost complete. If you travel far enough away from this system, terraforming will be finished before you return.", opad, highlight, new String[]{});
            }
            else
            {
                tooltip.addPara("Atmospheric detoxification on " + this.market.getName() + " is about %s complete.", opad, highlight, new String[]{format.format(percentComplete) + "%"});
            }


            if(this.nanoforge != null && this.nanoforge.getId().equals("pristine_nanoforge"))
            {
                tooltip.addPara("Production of atmosphere modifying materials is massively accelerated due to the installed pristine nanoforge. At this rate, atmospheric detoxification would take approximately %s cycles total.", opad, highlight, new String[]{"two"});
            }
            else if(this.nanoforge != null && this.nanoforge.getId().equals("corrupted_nanoforge"))
            {
                tooltip.addPara("Production of atmosphere modifying materials is accelerated due to the installed corrupted nanoforge. At this rate, atmospheric detoxification would take approximately %s cycles total.", opad, highlight, new String[]{"four"});
            }
            else
            {
                tooltip.addPara("Production of atmosphere modifying materials is very slow because there is no nanoforge installed. At this rate, atmospheric detoxification would take approximately %s cycles total.", opad, highlight, new String[]{"eight"});
            }
        }
    }
}

