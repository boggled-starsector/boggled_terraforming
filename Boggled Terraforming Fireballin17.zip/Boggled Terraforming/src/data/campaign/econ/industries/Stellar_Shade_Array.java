package data.campaign.econ.industries;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.*;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.econ.impl.Farming;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.IconRenderMode;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.CoreCampaignPluginImpl;
import com.fs.starfarer.api.impl.campaign.CoreScript;
import com.fs.starfarer.api.impl.campaign.events.CoreEventProbabilityManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposableLuddicPathFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposablePirateFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetRouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.MercFleetManagerV2;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.campaign.*;
import data.campaign.econ.BoggledTerraformingIDs;
import data.campaign.econ.boggledTerraformingTools;

public class Stellar_Shade_Array extends BaseIndustry
{
    private int lastMonthChecked = 0;
    private int monthsElapsed = 0;

    private boolean hasIsmaraSling = false;
    private boolean nonIsmaraTerraformingStartedIntelMessageSent = false;

    private boolean terraformFrozenToWaterTrigger = false;
    private boolean terraformVariantToTerranTrigger = false;

    public void advance(float amount)
    {
        super.advance(amount);

        if(this.isFunctional() && !this.isBuilding())
        {
            MarketAPI market = this.market;
            StarSystemAPI system = market.getStarSystem();
            PlanetAPI planet = market.getPlanetEntity();
            CampaignClockAPI clock = Global.getSector().getClock();
            boolean foundSlingThisLoop = false;
            boolean slingStatusChangedThisLoop = false;

            if(market.hasCondition("hot"))
            {
                market.removeCondition("hot");
                market.addTag("boggled_hot_removed");
            }

            if(market.hasCondition("very_hot"))
            {
                market.removeCondition("very_hot");
                market.addTag("boggled_very_hot_removed");
            }

            boggledTerraformingTools.refreshAquacultureAndFarming(market);

            //Ends the function before trying to terraform the planet if a EUTECK is active
            if(market.hasTag("boggled_euteck_terraformed"))
            {
                return;
            }

            //Check if monthsElapsed should be incremented
            if(clock.getMonth() != lastMonthChecked)
            {
                monthsElapsed++;
                lastMonthChecked = clock.getMonth();
            }

            //Load Ismara's Sling related variables. They will be unused for most planet types.
            if(boggledTerraformingTools.hasIsmaraSling(market))
            {
                foundSlingThisLoop = true;
            }
            else
            {
                foundSlingThisLoop = false;
            }

            if(foundSlingThisLoop && !hasIsmaraSling)
            {
                hasIsmaraSling = true;
                slingStatusChangedThisLoop = true;
            }
            else if(!foundSlingThisLoop && hasIsmaraSling)
            {
                hasIsmaraSling = false;
                slingStatusChangedThisLoop = true;
            }

            //Terraform if the triggers are met
            if(terraformVariantToTerranTrigger && !boggledTerraformingTools.playerTooClose(system))
            {
                boggledTerraformingTools.terraformVariantToTerran(market);
                terraformVariantToTerranTrigger = false;
                return;
            }
            else if(terraformFrozenToWaterTrigger && !boggledTerraformingTools.playerTooClose(system))
            {
                boggledTerraformingTools.terraformFrozenToWater(market);
                terraformFrozenToWaterTrigger = false;
                return;
            }

            //Process all the planet types
            if(boggledTerraformingTools.getPlanetType(planet).equals("gas_giant"))
            {
                return;
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("barren"))
            {
                return;
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("toxic"))
            {
                return;
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("desert"))
            {
                if(hasIsmaraSling && monthsElapsed >= (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithStellarReflectors") + 1))
                {
                    terraformVariantToTerranTrigger = true;
                }
                else if(hasIsmaraSling && foundSlingThisLoop && slingStatusChangedThisLoop)
                {
                    monthsElapsed = 0;
                    lastMonthChecked = clock.getMonth();

                    if (this.market.isPlayerOwned())
                    {
                        MessageIntel intel = new MessageIntel("Terraforming of " + market.getName(), Misc.getBasePlayerColor());
                        intel.addLine("    - Started");
                        intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                        intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                        Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
                    }
                }
                else if(!hasIsmaraSling && !foundSlingThisLoop && slingStatusChangedThisLoop)
                {
                    monthsElapsed = 0;
                    lastMonthChecked = clock.getMonth();

                    if (this.market.isPlayerOwned())
                    {
                        MessageIntel intel = new MessageIntel("Terraforming of " + market.getName(), Misc.getBasePlayerColor());
                        intel.addLine("    - Stalled (Lost access to water)");
                        intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                        intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                        Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
                    }
                }
                else if(!hasIsmaraSling)
                {
                    monthsElapsed = 0;
                    lastMonthChecked = clock.getMonth();
                    terraformVariantToTerranTrigger = false;
                }
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("terran"))
            {
                return;
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("water"))
            {
                return;
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("tundra"))
            {
                if(!nonIsmaraTerraformingStartedIntelMessageSent && market.isPlayerOwned())
                {
                    nonIsmaraTerraformingStartedIntelMessageSent = true;

                    MessageIntel intel = new MessageIntel("Terraforming of " + market.getName(), Misc.getBasePlayerColor());
                    intel.addLine("    - Started");
                    intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                    intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                    Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
                }

                if(monthsElapsed >= (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithStellarReflectors") + 1))
                {
                    terraformVariantToTerranTrigger = true;
                    return;
                }
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("jungle"))
            {
                if(!nonIsmaraTerraformingStartedIntelMessageSent && market.isPlayerOwned())
                {
                    nonIsmaraTerraformingStartedIntelMessageSent = true;

                    MessageIntel intel = new MessageIntel("Terraforming of " + market.getName(), Misc.getBasePlayerColor());
                    intel.addLine("    - Started");
                    intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                    intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                    Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
                }

                if(monthsElapsed >= (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithStellarReflectors") + 1))
                {
                    terraformVariantToTerranTrigger = true;
                    return;
                }
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("frozen"))
            {
                if(!nonIsmaraTerraformingStartedIntelMessageSent && market.isPlayerOwned())
                {
                    nonIsmaraTerraformingStartedIntelMessageSent = true;

                    MessageIntel intel = new MessageIntel("Terraforming of " + market.getName(), Misc.getBasePlayerColor());
                    intel.addLine("    - Started");
                    intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                    intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                    Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
                }

                if(monthsElapsed >= (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithStellarReflectors") + 1))
                {
                    terraformFrozenToWaterTrigger = true;
                    return;
                }
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("volcanic"))
            {
                return;
            }
            else if(boggledTerraformingTools.getPlanetType(planet).equals("unknown"))
            {
                return;
            }
        }
    }

    public boolean canBeDisrupted() {
        return false;
    }

    public float getBaseUpkeep()
    {
        //This fixes the erroneous upkeep calculation on the industry install page
        return this.getSpec().getUpkeep();
    }

    public void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Massively reduces upkeep cost.", 0.0F, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Massively reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void addBetaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Beta-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Beta-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Greatly reduces upkeep cost.", opad, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Greatly reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void addGammaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Gamma-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Gamma-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Reduces upkeep cost.", opad, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void applyAICoreToIncomeAndUpkeep() {
        //This code is overwritten below because all three AI cores reduce the upkeep by a different amount
    }

    public void updateAICoreToSupplyAndDemandModifiers() {
        //There is no supply or demand for this industry, but put this here as a placeholder for if that changes
    }

    public void applyIncomeAndUpkeep(float sizeOverride) {
        float size = (float)this.market.getSize();
        if (sizeOverride >= 0.0F) {
            size = sizeOverride;
        }

        float alphaCoreMult = 0.25f;
        float betaCoreMult = 0.50f;
        float gammaCoreMult = 0.75f;

        float sizeMult = getSizeMult(size);
        sizeMult = 1.0f; //Prevents colony size from altering the upkeep amount
        float stabilityMult = this.market.getIncomeMult().getModifiedValue();
        float upkeepMult = this.market.getUpkeepMult().getModifiedValue();
        int income = (int)(this.getSpec().getIncome() * sizeMult);
        if (income != 0) {
            this.getIncome().modifyFlatAlways("ind_base", (float)income, "Base value");
            this.getIncome().modifyMultAlways("ind_stability", stabilityMult, "Market income multiplier");
        } else {
            this.getIncome().unmodifyFlat("ind_base");
            this.getIncome().unmodifyMult("ind_stability");
        }

        int upkeep = (int)(this.getSpec().getUpkeep() * sizeMult);
        if(!this.market.isPlayerOwned())
        {
            upkeep = 0;
        }
        if (upkeep != 0) {
            this.getUpkeep().modifyFlatAlways("ind_base", (float)upkeep, "Base value");
            this.getUpkeep().modifyMultAlways("ind_hazard", upkeepMult, "Market upkeep multiplier");
            if(this.aiCoreId == null)
            {
                //Do not reduce upkeep, and remove any previous upkeep-reducing effects from AI cores that were previously installed
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("alpha_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_alpha", alphaCoreMult, "Alpha Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("beta_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_beta", betaCoreMult, "Beta Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("gamma_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_gamma", gammaCoreMult, "Gamma Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
            }
        } else {
            this.getUpkeep().unmodifyFlat("ind_base");
            this.getUpkeep().unmodifyMult("ind_hazard");
        }

        this.applyAICoreToIncomeAndUpkeep();
        if (!this.isFunctional()) {
            this.getIncome().unmodifyFlat("ind_base");
            this.getIncome().unmodifyMult("ind_stability");
        }
    }

    @Override
    public void finishBuildingOrUpgrading() {
        super.finishBuildingOrUpgrading();
    }

    @Override
    protected void buildingFinished()
    {
        super.buildingFinished();

        MarketAPI market = this.market;
        PlanetAPI planet = market.getPlanetEntity();
        CampaignClockAPI clock = Global.getSector().getClock();

        market.addTag("BOGGLED_STELLAR_SHADE_SHOW_TOOLTIP");

        boggledTerraformingTools.clearReflectorsInOrbit(market);

        if(!market.hasCondition("stellar_shade"))
        {
            market.addCondition("stellar_shade");
        }

        SectorEntityToken orbitFocus = market.getPrimaryEntity().getOrbitFocus();
        float orbitRadius = market.getPrimaryEntity().getRadius() + 80.0F;
        if (orbitFocus != null && orbitFocus.isStar())
        {
            StarSystemAPI system = market.getStarSystem();

            //First shade
            SectorEntityToken shadeAlpha = system.addCustomEntity("stellar_shade_alpha", ("Stellar Shade Alpha"), "stellar_shade", market.getFactionId());
            shadeAlpha.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle() + 154, orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
            shadeAlpha.setCustomDescriptionId("stellar_shade");

            //Second shade
            SectorEntityToken shadeBeta = system.addCustomEntity("stellar_shade_beta", ("Stellar Shade Beta"), "stellar_shade", market.getFactionId());
            shadeBeta.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle() + 180, orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
            shadeBeta.setCustomDescriptionId("stellar_shade");

            //Third shade
            SectorEntityToken shadeGamma = system.addCustomEntity("stellar_shade_gamma", ("Stellar Shade Gamma"), "stellar_shade", market.getFactionId());
            shadeGamma.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle() + 206, orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
            shadeGamma.setCustomDescriptionId("stellar_shade");
        }
        else
        {
            StarSystemAPI system = market.getStarSystem();

            //First shade
            SectorEntityToken shadeAlpha = system.addCustomEntity("stellar_shade_alpha", ("Stellar Shade Alpha"), "stellar_shade", market.getFactionId());
            shadeAlpha.setCircularOrbitPointingDown(market.getPrimaryEntity(), 0, orbitRadius, orbitRadius / 10.0F);
            shadeAlpha.setCustomDescriptionId("stellar_shade");

            //Second shade
            SectorEntityToken shadeBeta = system.addCustomEntity("stellar_shade_beta", ("Stellar Shade Beta"), "stellar_shade", market.getFactionId());
            shadeBeta.setCircularOrbitPointingDown(market.getPrimaryEntity(), 120, orbitRadius, orbitRadius / 10.0F);
            shadeBeta.setCustomDescriptionId("stellar_shade");

            //Third shade
            SectorEntityToken shadeGamma = system.addCustomEntity("stellar_shade_gamma", ("Stellar Shade Gamma"), "stellar_shade", market.getFactionId());
            shadeGamma.setCircularOrbitPointingDown(market.getPrimaryEntity(), 240, orbitRadius, orbitRadius / 10.0F);
            shadeGamma.setCustomDescriptionId("stellar_shade");
        }
    }

    @Override
    public void apply() {
        super.apply(true);

        this.applyIncomeAndUpkeep(-1f);
    }

    @Override
    public void unapply() {
        super.unapply();
    }

    @Override
    public void startBuilding() {
        super.startBuilding();
    }

    @Override
    public boolean isAvailableToBuild()
    {
        MarketAPI market = this.market;

        //Check to ensure non-player factions cannot build this
        if(!market.isPlayerOwned())
        {
            return false;
        }

        //Can't be built by station markets
        if(market.getPrimaryEntity().hasTag("station")) { return false; }

        //Can't be built on planets with poor light. All planets in nebulas and orbiting black holes have dark condition.
        if(market.hasCondition("dark") || market.hasCondition("poor_light")) { return false; }

        //Can't be built on planets that are already hot or very hot
        if(market.hasCondition("cold") || market.hasCondition("very_cold")) { return false; }

        //Can't be built on planets that already have an orbital shade array (only blocks Eochu Bres and Eventide in vanilla sector)
        if(boggledTerraformingTools.numReflectorsInOrbit(market) >= 3) { return false; }

        PlanetAPI planet = market.getPlanetEntity();

        //Check if spaceport is built
        if(!((market.hasIndustry(Industries.SPACEPORT) && market.getIndustry(Industries.SPACEPORT).isFunctional()) || (market.hasIndustry(Industries.MEGAPORT) && market.getIndustry(Industries.MEGAPORT).isFunctional())))
        {
            return false;
        }

        //Gas giant planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("gas_giant"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return false;
            }
        }

        //Barren planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("barren"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return false;
            }
        }

        //Toxic planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("toxic"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return false;
            }
        }

        //Desert planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("desert"))
        {
            return true;
        }

        //Terran planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("terran"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return false;
            }
        }

        //Water planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("water"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return false;
            }
        }

        //Tundra planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("tundra"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return false;
            }
        }

        //Jungle planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("jungle"))
        {
            return true;
        }

        //Frozen planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("frozen"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return false;
            }
        }

        //Volcanic planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("volcanic"))
        {
            //Never buildable
            return false;
        }

        //Unknown planet type
        if(boggledTerraformingTools.getPlanetType(planet).equals("unknown"))
        {
            //Never buildable
            return false;
        }

        return true;
    }

    @Override
    public boolean showWhenUnavailable()
    {
        return true;
    }

    @Override
    public String getUnavailableReason()
    {
        MarketAPI market = this.market;

        //Can't be built by station markets
        if(market.getPrimaryEntity().hasTag("station")) { return "Stations cannot be terraformed."; }

        //Can't be built on planets with poor light. All planets in nebulas and orbiting black holes have dark condition.
        if(market.hasCondition("dark") || market.hasCondition("poor_light")) { return (market.getName() + " already receives insufficient light. Stellar shades would only make conditions worse.."); }

        //Can't be built on planets that are already hot or very hot
        if(market.hasCondition("cold") || market.hasCondition("very_cold")) { return ("Temperatures on " + market.getName() + " are already too cold. Stellar shades would only make conditions worse."); }

        //Can't be built on planets that already have an orbital shade array (only blocks Eochu Bres and Eventide in vanilla sector)
        if(boggledTerraformingTools.numReflectorsInOrbit(market) >= 3) { return (market.getName() + " already has an array of stellar reflectors in orbit. Building more would not improve conditions any further."); }

        PlanetAPI planet = market.getPlanetEntity();

        //Check if spaceport is built
        if(!((market.hasIndustry(Industries.SPACEPORT) && market.getIndustry(Industries.SPACEPORT).isFunctional()) || (market.hasIndustry(Industries.MEGAPORT) && market.getIndustry(Industries.MEGAPORT).isFunctional())))
        {
            return (market.getName() + " lacks a functioning spaceport. It will be impossible to build a stellar shade array in orbit around " + market.getName() + " due to logistical problems until a spaceport becomes operational.");
        }

        //Gas giant planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("gas_giant"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return (market.getName() + " is very poorly suited for human habitation and/or terraforming. Temperatures on " + market.getName() + " are already within the ideal range so stellar shades would not provide any benefits.");
            }
        }

        //Barren planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("barren"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return (market.getName() + " is very poorly suited for human habitation and/or terraforming. Temperatures on " + market.getName() + " are already within the ideal range so stellar shades would not provide any benefits.");
            }
        }

        //Toxic planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("toxic"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return (market.getName() + " is poorly suited for human habitation due to atmospheric toxicity. An atmosphere adjuster may be capable of remedying this. Temperatures on " + market.getName() + " are already within the ideal range so stellar shades would not provide any benefits.");
            }
        }

        //Desert planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("desert"))
        {
            //Always buildable
        }

        //Terran planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("terran"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return (market.getName() + " is currently very well suited for human habitation. Temperatures on " + market.getName() + " are already within the ideal range so stellar shades would not provide any benefits.");
            }
        }

        //Water planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("water"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return (market.getName() + " is currently very well suited for human habitation. Temperatures on " + market.getName() + " are already within the ideal range so stellar shades would not provide any benefits.");
            }
        }

        //Tundra planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("tundra"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return ("Temperatures on " + market.getName() + " are already within the ideal range. Stellar mirrors may be able to terraform " + market.getName() + " into an Earth-like world.");
            }
        }

        //Jungle planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("jungle"))
        {
            //Always buildable
        }

        //Frozen planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("frozen"))
        {
            if(!(market.hasCondition("hot") || market.hasCondition("very_hot")))
            {
                return ("Temperatures on " + market.getName() + " are already within the ideal range. Stellar mirrors may be able to terraform " + market.getName() + " into an Earth-like world.");
            }
        }

        //Volcanic planet types
        if(boggledTerraformingTools.getPlanetType(planet).equals("volcanic"))
        {
            //Never buildable
            return ("Temperatures on " + market.getName() + " are largely driven by volcanism so stellar shades would be unable to improve conditions.");
        }

        //Unknown planet type
        if(boggledTerraformingTools.getPlanetType(planet).equals("unknown"))
        {
            //Never buildable
            return ("Error: This type of planet does not appear to be programmed into Boggled's Terraforming Mod. Please tell Boggled about this in the forum thread for this mod so he can add support for it. Unsupported planet type: " + market.getPlanetEntity().getTypeId());
        }

        return "Error: There was a code logic problem in the stellar shade getUnavailableReason() function. Please tell Boggled about this in the forum thread for this mod so he can fix it.";
    }

    public float getPatherInterest() {
        if (this.aiCoreId == null) {
            return 10.0F;
        } else if ("alpha_core".equals(this.aiCoreId)) {
            return 14.0F;
        } else if ("beta_core".equals(this.aiCoreId)) {
            return 12.0F;
        } else {
            return 11f;
        }
    }

    @Override
    protected void addRightAfterDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode)
    {
        MarketAPI market = this.market;
        PlanetAPI planet = market.getPlanetEntity();

        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        if(planet != null && (boggledTerraformingTools.getPlanetType(planet).equals("desert") || boggledTerraformingTools.getPlanetType(planet).equals("jungle")))
        {
            tooltip.addPara("Desert and jungle planets can be terraformed into a terran planet using a stellar shade array. It is buildable on these planet types even if the surface temperatures are already within the ideal range.", opad, highlight, new String[]{""});
        }

        if(this.isBuilding() || !market.hasTag("BOGGLED_STELLAR_SHADE_SHOW_TOOLTIP"))
        {
            return;
        }

        //Only display the below text if a UETECK is currently active.
        if(market.hasTag("boggled_euteck_terraformed") && market.hasCondition("euteck_active"))
        {
            tooltip.addPara(market.getName() + " is currently being terraformed by a Miller-Urey device.", opad, highlight, new String[]{""});
            return;
        }

        //Only display the below text if a UETECK has previously terraformed the planet.
        if(market.hasTag("boggled_euteck_terraformed") && !market.hasCondition("euteck_active"))
        {
            tooltip.addPara(market.getName() + " has been terraformed by a Miller-Urey device. Although " + market.getName() + " will not revert to a non-terran planet type, dismantling the stellar shade array may result in moderate deterioration of the climate.", opad, highlight, new String[]{""});
            return;
        }

        //Inserts terraforming status after the main description
        if(!hasIsmaraSling && (boggledTerraformingTools.getPlanetType(planet).equals("desert")))
        {
            tooltip.addPara("Terraforming of " + market.getName() + " is stalled due to a lack of sufficient water-ice. Build a Drone Control Nexus on an orbital station in this system, or build an Ismara's Sling on a water-covered, frozen or cryovolcanic planet in this system, to supply water-ice to " + market.getName() + ".", bad, opad);
        }
        else if(this.isFunctional() && (boggledTerraformingTools.getPlanetType(planet).equals("desert") || boggledTerraformingTools.getPlanetType(planet).equals("tundra") || boggledTerraformingTools.getPlanetType(planet).equals("jungle") || boggledTerraformingTools.getPlanetType(planet).equals("frozen")))
        {
            int monthsLeft = (Global.getSettings().getInt("boggledTerraformingNumberOfMonthsToFinishTerraformingWithStellarReflectors") + 1) - monthsElapsed;
            if(monthsLeft > 1)
            {
                tooltip.addPara("Approximately %s months remaining until terraforming is completed at " + market.getName() + ".\n\nConditions that can be improved by terraforming using stellar reflectors: Dust storms, suboptimal atmospheric density, extreme weather, inimical biosphere, meteor impacts, less than adequate farmland, and less than common organics.\n\nConditions that cannot be improved by terraforming using stellar reflectors: Tectonic activity, lack of a mild climate, high or low gravity, pollution, atmospheric toxicity, radiation, and lack of ore or volatiles.", opad, highlight, new String[]{"" + monthsLeft});
            }
            else if(monthsLeft == 1)
            {
                tooltip.addPara("Approximately %s month remaining until terraforming is completed at " + market.getName() + ".\n\nConditions that can be improved by terraforming using stellar reflectors: Dust storms, suboptimal atmospheric density, extreme weather, inimical biosphere, meteor impacts, less than adequate farmland, and less than common organics.\n\nConditions that cannot be improved by terraforming using stellar reflectors: Tectonic activity, lack of a mild climate, high or low gravity, pollution, atmospheric toxicity, radiation, and lack of ore or volatiles.", opad, highlight, new String[]{"" + monthsLeft});
            }
            else if(monthsLeft <= 0)
            {
                tooltip.addPara("Terraforming at " + market.getName() + " is almost complete. If you travel far enough away from this system, terraforming will be finished before you return.", opad, highlight, new String[]{""});
            }
        }
        else if(this.isFunctional() && boggledTerraformingTools.getPlanetType(planet).equals("gas_giant"))
        {
            tooltip.addPara("Conditions on " + market.getName() + " have been improved to the maximum extent possible. Gas giants cannot be terraformed to a different planet type using stellar shades. Stellar shades can only improve the temperature on gas giants.", opad, highlight, new String[]{""});
        }
        else if(this.isFunctional() && boggledTerraformingTools.getPlanetType(planet).equals("barren"))
        {
            tooltip.addPara("Conditions on " + market.getName() + " have been improved to the maximum extent possible using stellar shades. Planets like " + market.getName() + " cannot be terraformed to a different planet type using stellar shades. Stellar shades can only improve the temperature on this type of planet.", opad, highlight, new String[]{""});
        }
        else if(this.isFunctional() && boggledTerraformingTools.getPlanetType(planet).equals("toxic"))
        {
            tooltip.addPara("Conditions on " + market.getName() + " have been improved to the maximum extent possible using stellar shades. Planets like " + market.getName() + " cannot be terraformed to a different planet type using stellar shades. Stellar shades can only improve the temperature on this type of planet. An atmosphere adjuster may be able to improve conditions further.", opad, highlight, new String[]{""});
        }
        else if(this.isFunctional() && boggledTerraformingTools.getPlanetType(planet).equals("terran"))
        {
            tooltip.addPara("Conditions on " + market.getName() + " have been improved to the maximum extent possible using stellar shades. " + market.getName() + " already has Earth-like conditions. Stellar shades can only improve the temperature on Earth-like planets.", opad, highlight, new String[]{""});
        }
        else if(this.isFunctional() && boggledTerraformingTools.getPlanetType(planet).equals("water"))
        {
            tooltip.addPara("Conditions on " + market.getName() + " have been improved to the maximum extent possible using stellar shades. " + market.getName() + " already has Earth-like conditions. Stellar shades can only improve the temperature on Earth-like planets.", opad, highlight, new String[]{""});
        }
        else if(this.isFunctional() && boggledTerraformingTools.getPlanetType(planet).equals("volcanic"))
        {
            tooltip.addPara("Conditions on " + market.getName() + " have been improved to the maximum extent possible using stellar shades. Volcanic planets cannot be terraformed to a different planet type using stellar shades. Stellar shades cannot improve any conditions on volcanic planets because temperatures are largely driven by volcanism.", opad, highlight, new String[]{""});
        }
        else if(this.isFunctional() && boggledTerraformingTools.getPlanetType(planet).equals("unknown"))
        {
            tooltip.addPara("Error: This type of planet is not programmed in Boggled's Terraforming Mod. Please tell Boggled about this in the forum thread for this mod so he can add data for this planet type.", opad, highlight, new String[]{""});
        }
    }

    @Override
    public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
        super.notifyBeingRemoved(mode, forUpgrade);

        this.market.removeTag("BOGGLED_STELLAR_SHADE_SHOW_TOOLTIP");
    }
}

