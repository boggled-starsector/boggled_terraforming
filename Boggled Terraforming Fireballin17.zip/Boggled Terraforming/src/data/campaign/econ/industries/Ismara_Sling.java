package data.campaign.econ.industries;

import java.awt.Color;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.CoreCampaignPluginImpl;
import com.fs.starfarer.api.impl.campaign.CoreScript;
import com.fs.starfarer.api.impl.campaign.events.CoreEventProbabilityManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposableLuddicPathFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposablePirateFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetRouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.MercFleetManagerV2;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.campaign.CampaignPlanet;
import data.campaign.econ.BoggledTerraformingIDs;
import javax.lang.model.element.Element;
import data.campaign.econ.boggledTerraformingTools;

public class Ismara_Sling extends BaseIndustry
{
    public boolean canBeDisrupted() { return false; }

    @Override
    public void advance(float amount)
    {
        super.advance(amount);

        if(installedOnStation())
        {
            this.demand(0, "ships", 6, "Base value regardless of colony size");
            this.demand(0, "supplies", 6, "Base value regardless of colony size");
            this.demand(0, "fuel", 6, "Base value regardless of colony size");
        }
    }

    @Override
    protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode)
    {
        if ((mode != IndustryTooltipMode.NORMAL || this.isFunctional()) && installedOnStation())
        {
            Color highlight = Misc.getHighlightColor();
            Color negativeHighlight = Misc.getNegativeHighlightColor();
            float opad = 10.0F;

            String upkeepIncreasePercent = "x" + Integer.toString(getTotalDeficit() + 1);
            if(upkeepIncreasePercent.equals("x1"))
            {
                tooltip.addPara("Monthly upkeep multiplier due to shortages: %s", opad, highlight, new String[]{upkeepIncreasePercent});
                tooltip.addPara("*There are currently no shortages so the monthly upkeep is unmodified.", Misc.getGrayColor(), opad);
            }
            else
            {
                tooltip.addPara("Monthly upkeep multiplier due to shortages: %s", opad, negativeHighlight, new String[]{upkeepIncreasePercent});
            }

            tooltip.addPara("*Shortages result in a significant increase in monthly upkeep. Consider shutting down the Drone Control Nexus if shortages have made the monthly upkeep unaffordable.", Misc.getGrayColor(), opad);
        }
    }

    private int getTotalDeficit()
    {
        int totalDeficit = 0;

        Pair<String, Integer> deficitShips = this.getMaxDeficit(new String[]{"ships"});
        totalDeficit = totalDeficit + deficitShips.two;

        Pair<String, Integer> deficitSupplies = this.getMaxDeficit(new String[]{"supplies"});
        totalDeficit = totalDeficit + deficitSupplies.two;

        Pair<String, Integer> deficitFuel = this.getMaxDeficit(new String[]{"fuel"});
        totalDeficit = totalDeficit + deficitFuel.two;

        return totalDeficit;
    }

    private boolean installedOnStation()
    {
        if(this.market.getPrimaryEntity().hasTag("station"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public String getCurrentName()
    {
        if(installedOnStation())
        {
            return "Drone Control Nexus";
        }
        else
        {
            return "Ismara's Sling";
        }
    }

    @Override
    public String getCurrentImage()
    {
        if(installedOnStation() && targetPlanetInSystem())
        {
            return Global.getSettings().getSpriteName("boggled", "drone_control");
        }
        else if(installedOnStation() && !targetPlanetInSystem())
        {
            return Global.getSettings().getSpriteName("boggled", "drone_control_gray");
        }
        else if(!installedOnStation() && !targetPlanetInSystem())
        {
            return Global.getSettings().getSpriteName("boggled", "mass_driver_gray");
        }
        else
        {
            return this.getSpec().getImageName();
        }
    }

    private boolean targetPlanetInSystem()
    {
        SectorEntityToken entity = this.market.getPrimaryEntity();

        Iterator allPlanetsInSystem = entity.getStarSystem().getPlanets().iterator();
        while(allPlanetsInSystem.hasNext())
        {
            PlanetAPI planet = (PlanetAPI) allPlanetsInSystem.next();
            if (boggledTerraformingTools.getPlanetType(planet).equals("desert") && planet.getMarket() != null && planet.getMarket().isPlayerOwned())
            {
                if(boggledTerraformingTools.numReflectorsInOrbit(planet.getMarket()) >= 3)
                {
                    return true;
                }
            }
        }

        return false;
    }

    public float getBaseUpkeep()
    {
        //This fixes the erroneous upkeep calculation on the industry install page
        return this.getSpec().getUpkeep();
    }

    public void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Massively reduces upkeep cost.", 0.0F, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Massively reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void addBetaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Beta-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Beta-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Greatly reduces upkeep cost.", opad, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Greatly reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void addGammaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Gamma-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Gamma-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Reduces upkeep cost.", opad, highlight, "");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Reduces upkeep cost.", opad, highlight, "");
        }
    }

    public void applyAICoreToIncomeAndUpkeep() {
        //This code is overwritten below because all three AI cores reduce the upkeep by a different amount
    }

    public void updateAICoreToSupplyAndDemandModifiers() {
        //There is no supply or demand for this industry, but put this here as a placeholder for if that changes
    }

    public void applyIncomeAndUpkeep(float sizeOverride) {
        float size = (float)this.market.getSize();
        if (sizeOverride >= 0.0F) {
            size = sizeOverride;
        }

        float alphaCoreMult = 0.25f;
        float betaCoreMult = 0.50f;
        float gammaCoreMult = 0.75f;
        float shortagesMult = (float)(getTotalDeficit() + 1);

        float sizeMult = getSizeMult(size);
        sizeMult = 1.0f; //Prevents colony size from altering the upkeep amount
        float stabilityMult = this.market.getIncomeMult().getModifiedValue();
        float upkeepMult = this.market.getUpkeepMult().getModifiedValue();
        int income = (int)(this.getSpec().getIncome() * sizeMult);
        if (income != 0) {
            this.getIncome().modifyFlatAlways("ind_base", (float)income, "Base value");
            this.getIncome().modifyMultAlways("ind_stability", stabilityMult, "Market income multiplier");
        } else {
            this.getIncome().unmodifyFlat("ind_base");
            this.getIncome().unmodifyMult("ind_stability");
        }

        int upkeep = (int)(this.getSpec().getUpkeep() * sizeMult);
        if(!this.market.isPlayerOwned())
        {
            upkeep = 0;
        }
        if (upkeep != 0) {
            this.getUpkeep().modifyFlatAlways("ind_base", (float)upkeep, "Base value");
            this.getUpkeep().modifyMultAlways("ind_hazard", upkeepMult, "Market upkeep multiplier");

            if(installedOnStation())
            {
                this.getUpkeep().modifyMultAlways("boggled_shortages", shortagesMult, "Commodity shortages");
            }

            if(this.aiCoreId == null)
            {
                //Do not reduce upkeep, and remove any previous upkeep-reducing effects from AI cores that were previously installed
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("alpha_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_alpha", alphaCoreMult, "Alpha Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("beta_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_beta", betaCoreMult, "Beta Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_gamma");
            }
            else if(this.aiCoreId.equals("gamma_core"))
            {
                this.getUpkeep().modifyMultAlways("ind_ai_core_gamma", gammaCoreMult, "Gamma Core assigned");
                this.getUpkeep().unmodifyMult("ind_ai_core_alpha");
                this.getUpkeep().unmodifyMult("ind_ai_core_beta");
            }
        } else {
            this.getUpkeep().unmodifyFlat("ind_base");
            this.getUpkeep().unmodifyMult("ind_hazard");
        }

        this.applyAICoreToIncomeAndUpkeep();
        if (!this.isFunctional()) {
            this.getIncome().unmodifyFlat("ind_base");
            this.getIncome().unmodifyMult("ind_stability");
        }
    }

    @Override
    public void apply() {
        super.apply(true);

        this.applyIncomeAndUpkeep(-1f);
    }

    @Override
    public void unapply() {
        super.unapply();
    }

    @Override
    public void finishBuildingOrUpgrading() {
        super.finishBuildingOrUpgrading();
    }

    @Override
    protected void buildingFinished()
    {
        super.buildingFinished();
    }

    @Override
    public void startBuilding() { super.startBuilding(); }

    @Override
    protected String getDescriptionOverride()
    {
        if(this.market.getPrimaryEntity().hasTag("station"))
        {
            return "Establishes the command and control infrastructure necessary to support enormous swarms of asteroid tug drones. Once built, drones from this facility will disperse throughout the system to haul frozen asteroids to any desert worlds in need of additional water for terraforming. Requires a substantial amount of hulls, supplies and fuel for drone construction and maintenance regardless of market size.";
        }
        else
        {
            return null;
        }
    }

    @Override
    public boolean isAvailableToBuild()
    {

        //Check to ensure non-player factions cannot build this
        if(!this.market.isPlayerOwned())
        {
            return false;
        }

        //Can always be built by station markets
        if(this.market.getPrimaryEntity().hasTag("station")) { return true; }

        //Verify compatible planet type if not station
        PlanetAPI planet = this.market.getPlanetEntity();
        if(!boggledTerraformingTools.getPlanetType(planet).equals("water") && !boggledTerraformingTools.getPlanetType(planet).equals("frozen"))
        {
            return false;
        }

        return true;
    }

    @Override
    public boolean showWhenUnavailable()
    {
        return true;
    }

    @Override
    public String getUnavailableReason()
    {
        if(this.market.getPrimaryEntity().hasTag("station")) { return "Error. This structure should always be buildable on station markets. Please tell Boggled about this in the forum thread for this mod so he can fix this bug. Thank you!"; }

        //Verify compatible planet type
        PlanetAPI planet = this.market.getPlanetEntity();
        if(!boggledTerraformingTools.getPlanetType(planet).equals("water") && !boggledTerraformingTools.getPlanetType(planet).equals("frozen"))
        {
            return "Ismara's Sling can only be built on cryovolcanic, frozen and water-covered worlds.";
        }

        return "Error: Code logic problem is present in getUnavailableReasons() for Ismara's Sling/Drone Control Nexus. Please tell Boggled about this in the forum thread for this mod so he can fix this bug. Thank you!";
    }

    @Override
    protected void addRightAfterDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode)
    {
        MarketAPI market = this.market;

        float opad = 10.0F;
        float pad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        if(market.getPrimaryEntity().hasTag("station"))
        {
            tooltip.addPara("The purpose of the Drone Control Nexus is to supply water to desert worlds in this system to aid in terraforming. You must first begin the terraforming process on a desert world by building stellar shades in orbit. Without stellar shades, the climate will remain too inhospitable for a terran biosphere to take hold regardless of the additional water.", opad, highlight, new String[]{""});

            if(!targetPlanetInSystem())
            {
                tooltip.addPara("There are no desert planets with stellar reflectors in orbit in this system. The Drone Control Nexus cannot do anything useful right now.", bad, pad);
            }
            else
            {
                tooltip.addPara("The Drone Control Nexus is currently supplying water to a desert world with stellar reflectors in orbit for terraforming purposes. Once terraforming is complete, the Drone Control Nexus will no longer be necessary.", opad, highlight, new String[]{""});
            }
        }
        else
        {
            tooltip.addPara("The purpose of Ismara's Sling is to supply water to desert worlds in this system to aid in terraforming. You must first begin the terraforming process on a desert world by building stellar shades in orbit. Without stellar shades, the climate will remain too inhospitable for a terran biosphere to take hold regardless of the additional water.", opad, highlight, new String[]{""});

            if(!targetPlanetInSystem())
            {
                tooltip.addPara("There are no desert planets with stellar reflectors in orbit in this system. Ismara's Sling cannot do anything useful right now.", bad, pad);
            }
            else
            {
                tooltip.addPara("Ismara's Sling is currently supplying water to a desert world with stellar reflectors in orbit for terraforming purposes. Once terraforming is complete, Ismara's Sling will no longer be necessary.", opad, highlight, new String[]{""});
            }
        }
    }

    public float getPatherInterest() {
        if (this.aiCoreId == null) {
            return 10.0F;
        } else if ("alpha_core".equals(this.aiCoreId)) {
            return 14.0F;
        } else if ("beta_core".equals(this.aiCoreId)) {
            return 12.0F;
        } else {
            return 11f;
        }
    }
}
